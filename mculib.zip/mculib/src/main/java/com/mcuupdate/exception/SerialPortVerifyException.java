package com.mcuupdate.exception;

public class SerialPortVerifyException extends Exception {


    public SerialPortVerifyException(String message) {
        super(message);
    }
}
