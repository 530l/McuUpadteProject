package com.mcuupdate.utils;

import android.arch.core.BuildConfig;
import android.util.Log;

public class LogUtils {

    public static void e(String e) {
        if (BuildConfig.DEBUG) {

        }
        Log.e("lyf", e);
    }

    public static void i(String i) {
        if (BuildConfig.DEBUG) {

        }
        Log.i("lyf", i);
    }

    public static void ii(String i) {
        if (BuildConfig.DEBUG) {

        }
        Log.i("poi", i);
    }

    public static void ik(String i) {
        if (BuildConfig.DEBUG) {

        }
        Log.i("ik", i);
    }


    public static void d(String i) {
        if (BuildConfig.DEBUG) {

        }
        Log.i("dd", i);
    }

    public static void iparame(String i) {
        if (BuildConfig.DEBUG) {

        }
        Log.i("iparame", i);
    }

    public static void tt(String i) {
        if (BuildConfig.DEBUG) {

        }
        Log.i("xintiao", i);
    }
}
